=== Aribull ===
Contributors: arinio
Requires at least: 4.5
Tested up to: 5.7
Requires PHP: 5.6
License: GNU General Public License v2 or later
License URI: LICENSE

== Description ==
Aribull is a Beautiful Multipurpose, Responsive Theme with Easy and Power full Customization Options.  You can use it for your business, portfolio, blog, school, fitness, GYM, Magazine, News, Travels Agencies or any type of site. Its comes with beautiful slider. It has a very easy admin option panel where you can change anything easily. It supports all type devices like desktop , mobile and tablet etc. You can also easily upload logo , favicon etc. This theme made by arinio.com.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.



== Changelog ==
= 1.2 - April 03 2021 =
* fixed issues

= 1.1 - March 21 2021 =
* Initial release

== Credits ==

* Based on Underscores https://underscores.me/, (C) 2012-2020 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css https://necolas.github.io/normalize.css/, (C) 2012-2018 Nicolas Gallagher and Jonathan Neal, [MIT](https://opensource.org/licenses/MIT)
* Header image: License: CC0, https://pxhere.com/en/photo/52

* Twenty Twenty WordPress theme, Copyright 2019-2020 WordPress.org
Theme URI: https://wordpress.org/themes/twentytwenty/
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

* Twenty Nineteen WordPress theme, Copyright 2018-2020 WordPress.org
Theme URI: https://wordpress.org/themes/twentynineteen/
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html



* BreadcrumbTrail
@version   1.1.0
@author    Justin Tadlock <justin@justintadlock.com>
@copyright Copyright (c) 2008 - 2020, Justin Tadlock
@link      https://themehybrid.com/plugins/breadcrumb-trail
@license   http://www.gnu.org/licenses/old-licenses/gpl-2.0.html

* Font Awesome Free 5.3.1 by @fontawesome
https://fontawesome.com
License - https://fontawesome.com/license/free
Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License