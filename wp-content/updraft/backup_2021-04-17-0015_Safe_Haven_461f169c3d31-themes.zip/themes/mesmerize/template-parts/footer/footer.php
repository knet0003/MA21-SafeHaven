<div <?php echo mesmerize_footer_container('footer-simple') ?>>
    <div <?php echo mesmerize_footer_background('footer-content center-xs') ?>>
        <div class="gridContainer">
	        <div class="row middle-xs footer-content-row">
	            <div class="footer-content-col col-xs-12">
	                    <?php echo mesmerize_get_footer_copyright(); ?>
	            </div>
	        </div>
	    </div>
    </div>
</div>
